class HeaderComponent extends HTMLElement {
    connectedCallback() {
        fetch("/components/header/header.html")
            .then(response => response.text())
            .then(data => {
                this.innerHTML = data;
            });
    }
}

customElements.define("header-component", HeaderComponent);