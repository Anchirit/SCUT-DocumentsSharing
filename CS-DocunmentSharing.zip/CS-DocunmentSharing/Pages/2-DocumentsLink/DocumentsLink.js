// 内容映射：左侧内容的 data-id 与 GitHub 文件链接之间的关系
const contentMapping = {
    content1: {
        title: "内容 1 的标题",
        text: "这是内容 1 的详细描11述。",
        githubUrl: "https://github.com/Anchirit/SCUT-DocumentsSharing/blob/da7c58b83ea83f0c4c1904112895274059ad7333/%E5%A4%A7%E7%89%A9%E5%AE%9E%E9%AA%8C/README.md"
    },
    content2: {
        title: "内容 2 的标题",
        text: "这是内容 2 的详细描述。",
        githubUrl: "https://github.com/你的用户名/你的仓库名/blob/main/文件2.md"
    },
    content3: {
        title: "内容 3 的标题",
        text: "这是内容 3 的详细描述。",
        githubUrl: "https://github.com/你的用户名/你的仓库名/blob/main/文件3.md"
    },
    content4: {
        title: "内容 4 的标题",
        text: "这是内容 4 的详细描述。",
        githubUrl: "https://github.com/你的用户名/你的仓库名/blob/main/文件4.md"
    },
    content5: {
        title: "内容 5 的标题",
        text: "这是内容 5 的详细描述。",
        githubUrl: "https://github.com/你的用户名/你的仓库名/blob/main/文件5.md"
    }
};

// 选择所有左侧的内容项
const items = document.querySelectorAll(".scroll-item");

// 为每个内容项添加点击事件监听器
items.forEach(item => {
    item.addEventListener("click", function() {
        // 获取点击的内容项的 data-id
        const contentId = this.getAttribute("data-id");
        // 根据 contentId 从 contentMapping 获取对应内容
        const content = contentMapping[contentId];
        
        // 更新右侧内容区域，提供 GitHub 链接
        const rightContent = document.getElementById("right-content");
        rightContent.innerHTML = `
            <h2>${content.title}</h2>
            <p>${content.text}</p>
            <h3>GitHub 文件：</h3>
            <p><a href="${content.githubUrl}" target="_blank">查看或下载 GitHub 文件</a></p>
        `;
    });
});
