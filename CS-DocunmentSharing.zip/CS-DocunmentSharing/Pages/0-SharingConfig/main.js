// JavaScript: 启用 Ctrl + K 快捷键
document.addEventListener('keydown', function (e) {
    if (e.ctrlKey && e.key === 'k') {
        e.preventDefault(); // 防止默认行为
        document.getElementById('search-input').focus(); // 聚焦到搜索栏
    }
});